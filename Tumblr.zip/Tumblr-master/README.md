# Tumblr
Tumblr icon link for Google Chrome OS
download folder
open extensions in google chrome
more tools --> extensions
Load unpacked extension
choose folder "Tumblr"
open

easy!
